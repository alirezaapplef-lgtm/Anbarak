package com.anbarak.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.util.Locale

private data class Product(
    val id: Long = 0, val name: String, val category: String, val buy: Long,
    val sell: Long, val unit: String, val stock: Double, val photo: String = ""
)

private class InventoryDb(context: Context) : SQLiteOpenHelper(context, "anbarak.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,category TEXT,buy INTEGER,sell INTEGER,unit TEXT,stock REAL,photo TEXT)")
        db.execSQL("CREATE TABLE movements(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER,delta REAL,created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun all(): List<Product> {
        val out = mutableListOf<Product>()
        readableDatabase.rawQuery("SELECT * FROM products ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out += Product(c.getLong(0), c.getString(1), c.getString(2) ?: "", c.getLong(3), c.getLong(4), c.getString(5), c.getDouble(6), c.getString(7) ?: "")
        }
        return out
    }
    fun save(p: Product) {
        val v = ContentValues().apply { put("name",p.name); put("category",p.category); put("buy",p.buy); put("sell",p.sell); put("unit",p.unit); put("stock",p.stock); put("photo",p.photo) }
        if (p.id == 0L) writableDatabase.insert("products", null, v) else writableDatabase.update("products", v, "id=?", arrayOf(p.id.toString()))
    }
    fun adjust(id: Long, delta: Double): Boolean {
        val p = all().firstOrNull { it.id == id } ?: return false
        if (p.stock + delta < 0) return false
        writableDatabase.execSQL("UPDATE products SET stock=? WHERE id=?", arrayOf(p.stock + delta, id))
        writableDatabase.execSQL("INSERT INTO movements(product_id,delta) VALUES(?,?)", arrayOf(id, delta))
        return true
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = InventoryDb(this)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF176B57))) { AnbarakApp(db) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AnbarakApp(db: InventoryDb) {
    var products by remember { mutableStateOf(db.all()) }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Product?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Product?>(null) }
    var delta by remember { mutableStateOf("") }
    fun refresh() { products = db.all(); selected = selected?.let { s -> products.firstOrNull { it.id == s.id } } }
    val filtered = products.filter { it.name.contains(query, true) || it.category.contains(query, true) }
    Scaffold(topBar = {
        TopAppBar(title = { Text(if (selected == null) "انبارک" else "جزئیات کالا", fontWeight = FontWeight.Bold) }, navigationIcon = { if (selected != null) IconButton(onClick = { selected = null }) { Icon(Icons.Default.ArrowBack, "بازگشت") } }, actions = { if (selected == null) IconButton(onClick = { editing = null; showForm = true }) { Icon(Icons.Default.Add, "افزودن کالا") } })
    }, floatingActionButton = { if (selected == null) FloatingActionButton(onClick = { editing = null; showForm = true }) { Icon(Icons.Default.Add, "افزودن") } }) { pad ->
        if (selected == null) {
            Column(Modifier.padding(pad).fillMaxSize().padding(16.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard("تعداد کالا", fa(products.size.toLong()), Modifier.weight(1f))
                    StatCard("نیازمند شارژ", fa(products.count { it.stock <= 2 }.toLong()), Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                StatCard("ارزش موجودی", money(products.sumOf { it.buy * it.stock }.toLong()), Modifier.fillMaxWidth())
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("جست‌وجوی کالا...") }, leadingIcon = { Icon(Icons.Default.Search, null) })
                Spacer(Modifier.height(8.dp))
                if (filtered.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("هنوز کالایی ثبت نشده است. از دکمه + شروع کن.") }
                else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(filtered, key = { it.id }) { p -> Card(Modifier.fillMaxWidth().clickable { selected = p }, shape = RoundedCornerShape(14.dp)) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(p.name, fontWeight = FontWeight.Bold); Text(p.category.ifBlank { "بدون دسته‌بندی" }, style = MaterialTheme.typography.bodySmall); Text("موجودی: ${fa(p.stock)} ${p.unit}", color = MaterialTheme.colorScheme.primary) }; Text(money(p.sell), fontWeight = FontWeight.Bold) } } } }
            }
        } else {
            val p = products.firstOrNull { it.id == selected!!.id }
            if (p != null) Column(Modifier.padding(pad).fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(p.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                InfoRow("دسته‌بندی", p.category.ifBlank { "—" }); InfoRow("قیمت خرید", money(p.buy)); InfoRow("قیمت فروش", money(p.sell)); InfoRow("موجودی فعلی", "${fa(p.stock)} ${p.unit}")
                OutlinedTextField(delta, { delta = it }, label = { Text("مقدار ورود یا خروج") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { val n = delta.toDoubleOrNull(); if (n != null && n > 0) { db.adjust(p.id, n); delta = ""; refresh() } }, modifier = Modifier.weight(1f)) { Text("＋ ورود") }
                    Button(onClick = { val n = delta.toDoubleOrNull(); if (n != null && n > 0) { if (db.adjust(p.id, -n)) { delta = ""; refresh() } } }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("− خروج") }
                }
                OutlinedButton(onClick = { editing = p; showForm = true }, modifier = Modifier.fillMaxWidth()) { Text("ویرایش کالا") }
            }
        }
    }
    if (showForm) ProductDialog(editing, onDismiss = { showForm = false }, onSave = { db.save(it); showForm = false; refresh() })
}

@Composable private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) { Card(modifier) { Column(Modifier.padding(14.dp)) { Text(label, style = MaterialTheme.typography.bodySmall); Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) } } }
@Composable private fun InfoRow(label: String, value: String) { Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(label); Text(value, fontWeight = FontWeight.SemiBold) } }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProductDialog(existing: Product?, onDismiss: () -> Unit, onSave: (Product) -> Unit) {
    var name by remember { mutableStateOf(existing?.name ?: "") }; var category by remember { mutableStateOf(existing?.category ?: "") }
    var buy by remember { mutableStateOf(existing?.buy?.toString() ?: "0") }; var sell by remember { mutableStateOf(existing?.sell?.toString() ?: "0") }
    var stock by remember { mutableStateOf(existing?.stock?.toString() ?: "0") }; var unit by remember { mutableStateOf(existing?.unit ?: "عدد") }
    var photo by remember { mutableStateOf(existing?.photo ?: "") }; var expanded by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? -> photo = uri?.toString() ?: photo }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "افزودن کالا" else "ویرایش کالا") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("نام کالا *") }, singleLine = true)
            OutlinedTextField(category, { category = it }, label = { Text("دسته‌بندی") }, singleLine = true)
            OutlinedTextField(buy, { buy = it }, label = { Text("قیمت خرید (تومان)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            OutlinedTextField(sell, { sell = it }, label = { Text("قیمت فروش (تومان)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                OutlinedTextField(unit, {}, readOnly = true, label = { Text("واحد شمارش") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { listOf("عدد", "متر", "طاقه").forEach { DropdownMenuItem(text = { Text(it) }, onClick = { unit = it; expanded = false }) } }
            }
            OutlinedTextField(stock, { stock = it }, label = { Text("موجودی فعلی") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Text(if (photo.isBlank()) "انتخاب عکس کالا" else "عکس انتخاب شد؛ تغییر عکس") }
        }
    }, confirmButton = { Button(onClick = { if (name.isNotBlank()) onSave(Product(existing?.id ?: 0, name.trim(), category.trim(), buy.toLongOrNull() ?: 0, sell.toLongOrNull() ?: 0, unit, stock.toDoubleOrNull() ?: 0.0, photo)) }, enabled = name.isNotBlank()) { Text("ذخیره کالا") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

private fun fa(n: Long): String = NumberFormat.getIntegerInstance(Locale("fa", "IR")).format(n)
private fun fa(n: Double): String = NumberFormat.getNumberInstance(Locale("fa", "IR")).format(n)
private fun money(n: Long): String = "${fa(n)} تومان"
