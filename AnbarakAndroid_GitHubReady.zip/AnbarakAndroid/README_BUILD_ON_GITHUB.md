# ساخت APK با گوشی و GitHub Actions

1. یک repository جدید در GitHub بسازید و نام آن را `AnbarakAndroid` بگذارید.
2. محتویات همین پوشه را (خود پوشهٔ بیرونی را نه) در ریشهٔ repository بارگذاری کنید؛ باید فایل‌های `settings.gradle.kts` و `build.gradle.kts` و پوشهٔ `app` در ریشه دیده شوند.
3. شاخهٔ اصلی را `main` قرار دهید و فایل‌ها را commit کنید.
4. به زبانهٔ Actions بروید. اجرای `Build Anbarak APK` باید شروع شود؛ اگر شروع نشد، workflow را باز و `Run workflow` را بزنید.
5. پس از سبز شدن اجرا، وارد همان اجرای workflow شوید، پایین صفحه بخش Artifacts را پیدا کنید و `anbarak-debug-apk` را دانلود کنید.
6. ZIP دریافت‌شده را در گوشی استخراج کنید و فایل `app-debug.apk` را باز و نصب کنید. ممکن است اندروید اجازهٔ نصب از Chrome/Files را بخواهد.

این یک APK آزمایشی debug است، نه نسخهٔ انتشار امضاشده.
